﻿Select distinct cust.Country
From dbo.Customers as cust
order by cust.Country desc