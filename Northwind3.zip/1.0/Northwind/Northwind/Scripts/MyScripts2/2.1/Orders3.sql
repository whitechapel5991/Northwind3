﻿Select Count(distinct ord.CustomerID) as Result
from dbo.Orders as ord